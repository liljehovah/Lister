# program: m08 final project: lister (final version)
# author: ejm
# created: 2025-05-11
# ide: visual studio code
# purpose: simple gui note taking app
# no coding assistance was used in this program

# pseudo code
# import modules
# create directory for saving notes if not already there
# define image path for buttons
# utility function for multiple callbacks
# define callback functions
# define main window
# define create new note
# define load existing note
# define note taking window
# start program

# import relevant modules
import os
import tkinter as tk
from tkinter import filedialog, messagebox
from datetime import datetime

# create directory for saving notes
NOTES_DIR = os.path.join(os.path.dirname(__file__), 'data', 'notes')  # directory to store note files
os.makedirs(NOTES_DIR, exist_ok=True)  # create the notes directory if it doesn't exist

# image path for buttons
IMAGES_DIR = os.path.join(os.path.dirname(__file__), 'data', 'images')  # directory for image assets
ICON_GREEN_PATH = os.path.join(IMAGES_DIR, 'green.png')  # path to green icon for buttons
ICON_RED_PATH = os.path.join(IMAGES_DIR, 'red.png')  # path to red icon for buttons

# utility function to combine multiple callbacks
def combined_callback(*funcs):
    def wrapper():
        for f in funcs:
            f()
    return wrapper

# placeholder callback functions
def log_action():
    print("action logged")

def audit_log():
    print("audit entry recorded")

def notify():
    print("notification sent")

# define main window
def create_main_window():
    root = tk.Tk()  # main application window
    root.title('lister by ejm')  # window title
    root.geometry('400x300')  # window size

    title = tk.Label(root, text='Lister by ejm', font=('arial', 20))  # title label
    title.pack(pady=20)

    btn_new = tk.Button(root, text='Create New Note', width=20,
                        command=combined_callback(log_action, audit_log, create_new_note))  # button to create a new note
    btn_new.pack(pady=10)

    btn_load = tk.Button(root, text='Load Existing Note', width=20,
                         command=combined_callback(log_action, notify, load_existing_note))  # button to load a note
    btn_load.pack(pady=10)

    btn_exit = tk.Button(root, text='Exit', width=20,
                         command=combined_callback(log_action, audit_log, root.destroy))  # button to exit the app
    btn_exit.pack(pady=10)

    root.mainloop()  # start the main event loop

# define create new note
def create_new_note():
    note_window(editing=False)  # open a new note window

# define load existing note
def load_existing_note():
    files = os.listdir(NOTES_DIR)  # list of saved notes
    if not files:
        messagebox.showinfo('No Notes', 'No notes found to load.')  # alert if no notes exist
        return

    load_window = tk.Toplevel()  # new window to list notes
    load_window.title('Load Note')  # window title
    load_window.geometry('300x400')  # window size

    file_listbox = tk.Listbox(load_window)  # listbox for file names
    file_listbox.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

    for file in files:
        file_listbox.insert(tk.END, file)  # insert file names into listbox

    icon_green = tk.PhotoImage(file=ICON_GREEN_PATH)  # load green icon

    def open_selected_file():
        selected = file_listbox.curselection()  # get selected file index
        if selected:
            filename = file_listbox.get(selected[0])  # get file name
            filepath = os.path.join(NOTES_DIR, filename)  # construct file path
            load_window.destroy()  # close list window
            note_window(filepath)  # open selected note

    btn_open = tk.Button(load_window, text=' Open', image=icon_green, compound='left',
                         command=combined_callback(log_action, notify, open_selected_file))  # button to open selected note
    btn_open.image = icon_green
    btn_open.pack(pady=5)

# define note taking window
def note_window(filepath=None, editing=True):
    window = tk.Toplevel()  # new window for editing
    window.title('Edit Note' if filepath else 'New Note')  # window title based on mode
    window.geometry('500x500')  # window size

    text_area = tk.Text(window, wrap=tk.WORD)  # text area for note content
    text_area.pack(fill=tk.BOTH, expand=True)

    if filepath:
        with open(filepath, 'r') as f:
            content = f.read()  # read existing note
            text_area.insert(tk.END, content)  # load content into text area

    def save_note():
        content = text_area.get('1.0', tk.END).strip()  # get content from text area
        if not content:
            messagebox.showwarning('Empty Note', 'Cannot save an empty note.')  # warn if empty
            return

        if filepath:
            save_path = filepath  # overwrite existing note
        else:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')  # generate file name
            save_path = os.path.join(NOTES_DIR, f'{timestamp}.txt')  # path for new note

        with open(save_path, 'w') as f:
            f.write(content)  # save note

        messagebox.showinfo('Saved', f'Note saved to {save_path}')  # confirm save
        window.destroy()  # close note window

    def quit_without_saving():
        window.destroy()  # close window without saving

    btn_frame = tk.Frame(window)  # frame for buttons
    btn_frame.pack(fill=tk.X)

    icon_green = tk.PhotoImage(file=ICON_GREEN_PATH)  # green check icon for save
    icon_red = tk.PhotoImage(file=ICON_RED_PATH)  # red x icon for quit

    btn_save = tk.Button(btn_frame, text=' Save', image=icon_green, compound='left',
                         command=combined_callback(log_action, audit_log, save_note))  # button to save note
    btn_save.image = icon_green
    btn_save.pack(side=tk.LEFT, padx=10, pady=5)

    btn_quit = tk.Button(btn_frame, text=' Quit Without Saving', image=icon_red, compound='left',
                         command=combined_callback(log_action, notify, quit_without_saving))  # button to quit without saving
    btn_quit.image = icon_red
    btn_quit.pack(side=tk.RIGHT, padx=10, pady=5)

# start program
create_main_window()
